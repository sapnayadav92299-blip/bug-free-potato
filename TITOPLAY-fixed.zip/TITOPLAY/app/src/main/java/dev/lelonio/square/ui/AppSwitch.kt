package dev.lelonio.square.ui

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import dev.lelonio.square.R
import dev.lelonio.square.SquareApplication
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * The change of dress: the app's own look, and the AETHER one.
 *
 * Holding the home icon for five seconds turns the logo over black, and while
 * the screen is covered the whole app is dressed the other way, then the black
 * lifts. Only the look changes (colours, type, the page behind); the bar and
 * everything the pages do stay as they are.
 */
object AppSwitch {
    /** True while the logo is turning, until the black has lifted. */
    val spinning = mutableStateOf(false)

    fun begin(context: Context, view: View?): Boolean {
        if (spinning.value) return false
        view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        spinning.value = true
        return true
    }

    fun flip(context: Context) {
        val prefs = (context.applicationContext as SquareApplication).preferences
        prefs.setAetherSkin(!prefs.aetherSkin.value)
    }
}

/** Held for [ms] without letting go; the touch itself is left alone, so a tap still taps. */
fun Modifier.holdToSwitch(ms: Long = 5_000L): Modifier = composed {
    val context = LocalContext.current
    val view = LocalView.current
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var lifted = false
            val stillDown = withTimeoutOrNull(ms) {
                while (!lifted) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.changes.none { it.pressed }) lifted = true
                }
                true
            }
            if (stillDown == null) AppSwitch.begin(context, view)
        }
    }
}

/** The logo turning over black while the app changes dress underneath. */
@Composable
fun AppSwitchOverlay() {
    if (!AppSwitch.spinning.value) return
    val context = LocalContext.current
    val turn = remember { Animatable(0f) }
    val dark = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { turn.animateTo(1f, tween(2000, easing = FastOutSlowInEasing)) }
        dark.animateTo(1f, tween(450))
        AppSwitch.flip(context)
        delay(700)
        dark.animateTo(0f, tween(600))
        AppSwitch.spinning.value = false
    }
    Box(
        Modifier
            .fillMaxSize()
            .alpha(dark.value)
            .background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.splash_logo),
            contentDescription = null,
            modifier = Modifier
                .size(178.dp)
                .graphicsLayer {
                    rotationZ = turn.value * 720f
                    val s = 1f - 0.25f * kotlin.math.sin(turn.value * Math.PI).toFloat()
                    scaleX = s
                    scaleY = s
                },
        )
    }
}


/**
 * The bars out of the way.
 *
 * Holding the app's name on the home page clears the top controls and the
 * bottom bar, so the page is all there is; holding it again brings them back.
 */
object Chrome {
    val hidden = mutableStateOf(false)
}

/** A long press toggles [Chrome.hidden], with a tick under the finger. */
fun Modifier.toggleChromeOnHold(): Modifier = composed {
    val view = LocalView.current
    pointerInput(Unit) {
        detectTapGestures(
            onLongPress = {
                view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                Chrome.hidden.value = !Chrome.hidden.value
            },
        )
    }
}

/** Takes no room and shows nothing while [Chrome.hidden]; the bar is otherwise untouched. */
fun Modifier.chromeHidden(): Modifier = layout { measurable, constraints ->
    if (Chrome.hidden.value) {
        layout(0, 0) {}
    } else {
        val placeable = measurable.measure(constraints)
        layout(placeable.width, placeable.height) { placeable.place(0, 0) }
    }
}
